package com.ecommerce.Exception;

public class ProductNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;

}
